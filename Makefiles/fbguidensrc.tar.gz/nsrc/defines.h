#ifndef DEFINES_H_
#define DEFINES_H_

#define NO_GPS
#define NO_TMTC
#define NO_MPF
#define NO_DET

// how long will the com thread sleep each round
#define COM_THREAD_SLEEP 10000

#endif
