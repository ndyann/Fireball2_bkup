#ifndef DETECTOR_DATA_H_
#define DETECTOR_DATA_H_


// any information that gets sent to the detector goes here
// not much for now.
typedef struct detector_data_t { 
  unsigned short count;
  unsigned long frame;
} detector_data_t;

#endif // DETECTOR_DATA_H_
