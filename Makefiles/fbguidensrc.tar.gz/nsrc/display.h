#ifndef DISP_H
#define DISP_H

typedef struct display_settings_t{
  int hello;
} display_settings_t;

#endif
