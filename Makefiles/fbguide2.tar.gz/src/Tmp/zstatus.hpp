
#ifndef ZSTATUS_HPP
#define ZSTATUS_HPP
 
#include <iostream>

#include "Cpco_cl_com.h"
#include "Cpco_me4.h"

#include "VersionNo.h"
#include "file12.h"

//#include "main.hpp"


#endif
