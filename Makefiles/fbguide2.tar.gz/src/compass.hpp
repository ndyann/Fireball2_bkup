//
//  MINT
//	Compass communication functions
//
//  Created by Lucas Sousa de Oliveira on 08/29/12.
//  Property of NASA - Goddard Space Flight Center
//
#ifndef rubble_mint_compass
#define rubble_mint_compass



#endif
